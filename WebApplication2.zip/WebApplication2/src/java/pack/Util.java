/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author ankush.bist
 */
public class Util {

    public static String returnFormattedDate(String strDate) {
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format2 = new SimpleDateFormat("yyyy/MM/dd");
        Date date = null;
        try {
            date = (Date) format1.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return format2.format(date);
        //return date;
    }

    public static String returnReverseFormattedDate(String strDate) {
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            date = (Date) format1.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return format2.format(date);
    }
}
