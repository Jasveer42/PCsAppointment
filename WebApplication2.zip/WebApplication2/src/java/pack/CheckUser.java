/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ankush.bist
 */
public class CheckUser {

    public boolean checkUserIdentification(Connection conn, String userId) {
        try {
            String sql = "SELECT * FROM IDENTIFICATION WHERE UNIQUEIDENTIFICATIONNO=?";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, userId);

            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return true;
            }
            rs.close();
            stm.close();
        } catch (Exception ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return false;
    }

    public boolean checkUserAlreadyRegistered(Connection conn, String userId) {
        try {
            String sql = "SELECT * FROM USERS WHERE LOGINID=?";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, userId);

            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return true;
            }
            rs.close();
            stm.close();
        } catch (Exception ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return false;
    }

    public boolean checkUserExists(Connection conn, String userId) {
        try {
            String sql = "SELECT * FROM USERS WHERE LOGINID=?";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, userId);

            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return true;
            }
            rs.close();
            stm.close();
        } catch (Exception ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return false;
    }

    public boolean checkUserTypeExists(Connection conn, String userId, String userType) {
        try {
            String sql = "SELECT * FROM USERS WHERE LOGINID=? and USERTYPE=?";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, userId);
            stm.setString(2, userType);

            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return true;
            }
            rs.close();
            stm.close();
        } catch (Exception ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return false;
    }
    
     public boolean appointmentAlreadyRequested(Connection conn, String userId, String apId) {
        try {
            String sql = "SELECT * FROM REQUESTS WHERE USERID=? and AP_ID=?";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, userId);
            stm.setString(2, apId);

            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                return true;
            }
            rs.close();
            stm.close();
        } catch (Exception ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return false;
    }

}
