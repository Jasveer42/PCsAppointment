/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Path("Application")
public class GenericResource {

    @GET
    @Path("test")
    @Produces(MediaType.APPLICATION_JSON)
    public String getDate() throws SQLException {
        JSONObject mainObject = new JSONObject();
        mainObject.accumulate("Status", "ok");
        try {
            Connection con = GetConnection.getConn();
        } catch (Exception e) {
            mainObject.accumulate("error", e);
        }
        return mainObject.toString();
    }

    @GET
    @Path("Registration/{userId}&{firstName}&{lastName}&{password}&{phone}&{userType}")
    @Produces(MediaType.APPLICATION_JSON)
    public String Registration(@PathParam("userId") String loginId,
            @PathParam("firstName") String firstName, @PathParam("lastName") String lastName,
            @PathParam("password") String password, @PathParam("phone") String phone,
            @PathParam("userType") String userType) throws SQLException {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();

            if (!checkUser.checkUserIdentification(con, loginId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does not Exists.");
            } else if (checkUser.checkUserAlreadyRegistered(con, loginId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Already Registered.");
            } else {

                String sql = "INSERT INTO USERS(FIRSTNAME, LASTNAME, LOGINID, PASSWORD, USERTYPE, PHONE) VALUES(?,?,?,?,?,?)";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, firstName);
                stm.setString(2, lastName);
                stm.setString(3, loginId);
                stm.setString(4, password);
                stm.setString(5, userType);
                stm.setString(6, phone);

                int value = stm.executeUpdate();

                if (value >= 1) {
                    mainObject.accumulate("Status", "Ok");
                    mainObject.accumulate("Message", "User Registered.");
                } else {
                    mainObject.accumulate("Status", "Error");
                    mainObject.accumulate("Message", "Unable to Register User.");
                }

                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Registration. " + ex);
        }

        return mainObject.toString();
    }

    @GET
    @Path("Login/{userType}&{userId}&{password}")
    @Produces(MediaType.APPLICATION_JSON)
    public String Login(@PathParam("userType") String userType, @PathParam("userId") String userId, @PathParam("password") String password) {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();
            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User is not Registered!");
            } else if (!checkUser.checkUserTypeExists(con, userId, userType)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Type Mismatch!");
            } else {
                String sql = "SELECT LOGINID, FIRSTNAME, LASTNAME, USERTYPE FROM USERS WHERE USERTYPE=? AND LOGINID=? AND PASSWORD=?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userType);
                stm.setString(2, userId);
                stm.setString(3, password);

                ResultSet rs = stm.executeQuery();
                String status = "Error", message = "Credentials are wrong.";
                while (rs.next()) {
                    status = "Ok";
                    mainObject.accumulate("UserID", rs.getString("LOGINID"));
                    mainObject.accumulate("FirstName", rs.getString("FIRSTNAME"));
                    mainObject.accumulate("LastName", rs.getString("LASTNAME"));
                    mainObject.accumulate("UserType", rs.getString("USERTYPE"));
                    message = "Login Success";
                }
                mainObject.accumulate("Status", status);
                mainObject.accumulate("Message", message);

                rs.close();
                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error Server" + ex);
        }

        return mainObject.toString();
    }

    @GET
    @Path("UserProfile/{Id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String UserProfile(@PathParam("Id") String userId) {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();
            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does Not Exists!");
            } else {
                String sql = "SELECT FIRSTNAME, LASTNAME, USERTYPE, PHONE, LOGINID FROM USERS Where LOGINID=?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);

                ResultSet rs = stm.executeQuery();

                JSONObject singleUser = new JSONObject();
                while (rs.next()) {
                    singleUser.accumulate("fname", rs.getString("FIRSTNAME"));
                    singleUser.accumulate("lname", rs.getString("LASTNAME"));
                    singleUser.accumulate("userType", rs.getString("USERTYPE"));
                    singleUser.accumulate("phone", rs.getString("PHONE"));
                    singleUser.accumulate("userId", rs.getString("LOGINID"));
                }

                mainObject.accumulate("Status", "Ok");
                mainObject.accumulate("Message", "User Info Fetched.");
                mainObject.accumulate("Detail", singleUser);

                rs.close();
                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Fetching User Info.");
        }

        return mainObject.toString();
    }

    @GET
    @Path("createAppointmentSlot/{userId}&{apDate}&{startTime}&{endTime}")
    @Produces(MediaType.APPLICATION_JSON)
    public String createAppointmentSlot(@PathParam("userId") String userId,
            @PathParam("apDate") String apDate, @PathParam("startTime") String startTime,
            @PathParam("endTime") String endTime) throws SQLException {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();

            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does not Exists.");
            } else {

                String sql = "INSERT INTO APPOINTMENT_SLOTS(RECID, USERID, AP_DATE, START_TIME, END_TIME)"
                        + " VALUES(AP_SLOT_SEQ.NEXTVAL,?,TO_DATE(?, 'YYYY/MM/DD'),?,?)";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);
                stm.setString(2, Util.returnFormattedDate(apDate));
                stm.setString(3, startTime);
                stm.setString(4, endTime);

                int value = stm.executeUpdate();

                if (value >= 1) {
                    mainObject.accumulate("Status", "Ok");
                    mainObject.accumulate("Message", "Appointment Slot Registered.");
                } else {
                    mainObject.accumulate("Status", "Error");
                    mainObject.accumulate("Message", "Unable to Register Appointment Slot.");
                }

                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Registering Appointment Slot. " + ex);
        }

        return mainObject.toString();
    }

    @GET
    @Path("consultantAppointmentSlots/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public String consultantAppointmentSlots(@PathParam("userId") String userId) {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();
            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does Not Exists!");
            } else {
                String sql = "SELECT * FROM APPOINTMENT_SLOTS Where USERID=?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);

                ResultSet rs = stm.executeQuery();

                JSONArray arrData = new JSONArray();
                while (rs.next()) {
                    JSONObject singleUser = new JSONObject();

                    singleUser.accumulate("Id", rs.getString("RECID"));
                    singleUser.accumulate("Date", rs.getString("AP_DATE"));
                    singleUser.accumulate("StartTime", rs.getString("START_TIME"));
                    singleUser.accumulate("EndTime", rs.getString("END_TIME"));

                    arrData.add(singleUser);
                }

                mainObject.accumulate("Status", "Ok");
                mainObject.accumulate("Message", "Consultant Appointment Slots Fetched.");
                mainObject.accumulate("Detail", arrData);

                rs.close();
                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Fetching Consultant Appointment Slots.");
        }

        return mainObject.toString();
    }

    @GET
    @Path("allAppointmentSlots/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public String allAppointmentSlots(@PathParam("userId") String userId) {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();
            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does Not Exists!");
            } else {
                String sql = "SELECT APPOINTMENT_SLOTS.*, USERS.FIRSTNAME, USERS.LASTNAME,"
                        + " REQUESTS.REQUEST_DATE, REQUESTS.STATUS FROM APPOINTMENT_SLOTS"
                        + " LEFT JOIN USERS ON USERS.LOGINID=APPOINTMENT_SLOTS.USERID"
                        + " LEFT JOIN REQUESTS ON REQUESTS.USERID=? AND REQUESTS.AP_ID=APPOINTMENT_SLOTS.RECID";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);

                ResultSet rs = stm.executeQuery();

                JSONArray arrData = new JSONArray();
                while (rs.next()) {
                    JSONObject singleUser = new JSONObject();

                    singleUser.accumulate("Id", rs.getString("RECID"));
                    singleUser.accumulate("UserId", rs.getString("USERID"));
                    singleUser.accumulate("UserName", rs.getString("FIRSTNAME") + " " + rs.getString("LASTNAME"));
                    singleUser.accumulate("Date", rs.getString("AP_DATE"));
                    singleUser.accumulate("StartTime", rs.getString("START_TIME"));
                    singleUser.accumulate("EndTime", rs.getString("END_TIME"));
                    singleUser.accumulate("RequestDate", rs.getString("REQUEST_DATE") != null ? rs.getString("REQUEST_DATE") : "");
                    singleUser.accumulate("RequestStatus", rs.getString("STATUS") != null ? rs.getString("STATUS") : "");

                    arrData.add(singleUser);
                }

                mainObject.accumulate("Status", "Ok");
                mainObject.accumulate("Message", "Consultant Appointment Slots Fetched.");
                mainObject.accumulate("Detail", arrData);

                rs.close();
                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Fetching Consultant Appointment Slots.");
        }

        return mainObject.toString();
    }

    @GET
    @Path("requestAppointment/{userId}&{apId}")
    @Produces(MediaType.APPLICATION_JSON)
    public String requestAppointment(@PathParam("userId") String userId,
            @PathParam("apId") String apId) throws SQLException {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();

            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does not Exists.");
            } else if (checkUser.appointmentAlreadyRequested(con, userId, apId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "Appoinment Slot Already Requested By You.");
            } else {

                String sql = "INSERT INTO REQUESTS(RECID, USERID, AP_ID, STATUS)"
                        + " VALUES(REQUEST_SEQ.NEXTVAL, ?,?, 'PENDING')";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);
                stm.setString(2, apId);

                int value = stm.executeUpdate();

                if (value >= 1) {
                    mainObject.accumulate("Status", "Ok");
                    mainObject.accumulate("Message", "Appointment Requested.");
                } else {
                    mainObject.accumulate("Status", "Error");
                    mainObject.accumulate("Message", "Unable to Request Appointment Slot.");
                }

                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Requesting Appointment Slot. " + ex);
        }

        return mainObject.toString();
    }

    @GET
    @Path("studentRequestResponse/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public String studentRequestResponse(@PathParam("userId") String userId) throws SQLException {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();

            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does not Exists.");
            } else {
                String sql = "SELECT APPOINTMENT_SLOTS.*, USERS.FIRSTNAME, USERS.LASTNAME, REQUESTS.STATUS, REQUESTS.REQUEST_DATE FROM REQUESTS"
                        + " LEFT JOIN APPOINTMENT_SLOTS ON REQUESTS.AP_ID=APPOINTMENT_SLOTS.RECID"
                        + " LEFT JOIN USERS ON USERS.LOGINID=APPOINTMENT_SLOTS.USERID"
                        + " WHERE REQUESTS.USERID=?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);

                ResultSet rs = stm.executeQuery();

                JSONArray arrData = new JSONArray();
                while (rs.next()) {
                    JSONObject singleUser = new JSONObject();

                    singleUser.accumulate("Id", rs.getString("RECID"));
                    singleUser.accumulate("ConsultantUserId", rs.getString("USERID"));
                    singleUser.accumulate("ConsultantUserName", rs.getString("FIRSTNAME") + " " + rs.getString("LASTNAME"));
                    singleUser.accumulate("ApDate", rs.getString("AP_DATE"));
                    singleUser.accumulate("ApStartTime", rs.getString("START_TIME"));
                    singleUser.accumulate("ApEndTime", rs.getString("END_TIME"));
                    singleUser.accumulate("RequestDate", rs.getString("REQUEST_DATE"));
                    singleUser.accumulate("RequestStatus", rs.getString("STATUS"));

                    arrData.add(singleUser);
                }

                mainObject.accumulate("Status", "Ok");
                mainObject.accumulate("Message", "Consultant Appointment Slots Fetched.");
                mainObject.accumulate("Detail", arrData);

                rs.close();
                stm.close();

                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Requesting Appointment Slot. " + ex);
        }

        return mainObject.toString();
    }

    @GET
    @Path("studentRequests/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public String studentRequests(@PathParam("userId") String userId) throws SQLException {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();

            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does not Exists.");
            } else {
                String sql = "SELECT APPOINTMENT_SLOTS.RECID AS APID, APPOINTMENT_SLOTS.AP_DATE,"
                        + " APPOINTMENT_SLOTS.START_TIME, APPOINTMENT_SLOTS.END_TIME,"
                        + " USERS.LOGINID, USERS.FIRSTNAME, USERS.LASTNAME,"
                        + " REQUESTS.RECID, REQUESTS.STATUS, REQUESTS.REQUEST_DATE FROM APPOINTMENT_SLOTS"
                        + " INNER JOIN REQUESTS ON REQUESTS.AP_ID=APPOINTMENT_SLOTS.RECID"
                        + " LEFT JOIN USERS ON USERS.LOGINID=REQUESTS.USERID"
                        + " WHERE APPOINTMENT_SLOTS.USERID=?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, userId);

                ResultSet rs = stm.executeQuery();

                JSONArray arrData = new JSONArray();
                while (rs.next()) {
                    JSONObject singleUser = new JSONObject();

                    singleUser.accumulate("RequestId", rs.getString("RECID"));
                    singleUser.accumulate("ApId", rs.getString("APID"));
                    singleUser.accumulate("UserId", rs.getString("LOGINID"));
                    singleUser.accumulate("UserName", rs.getString("FIRSTNAME") + " " + rs.getString("LASTNAME"));
                    singleUser.accumulate("ApDate", rs.getString("AP_DATE"));
                    singleUser.accumulate("ApStartTime", rs.getString("START_TIME"));
                    singleUser.accumulate("ApEndTime", rs.getString("END_TIME"));
                    singleUser.accumulate("RequestDate", rs.getString("REQUEST_DATE"));
                    singleUser.accumulate("RequestStatus", rs.getString("STATUS"));

                    arrData.add(singleUser);
                }

                mainObject.accumulate("Status", "Ok");
                mainObject.accumulate("Message", "Student Requests Fetched.");
                mainObject.accumulate("Detail", arrData);

                rs.close();
                stm.close();

                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Fetching Student Requests. " + ex);
        }

        return mainObject.toString();
    }

    @GET
    @Path("respondToRequest/{userId}&{apId}&{requestId}&{studentId}&{status}")
    @Produces(MediaType.APPLICATION_JSON)
    public String respondToRequest(@PathParam("userId") String userId, @PathParam("apId") String apId,
            @PathParam("requestId") String requestId, @PathParam("studentId") String studentId,
            @PathParam("status") String status) throws SQLException {
        CheckUser checkUser = new CheckUser();
        JSONObject mainObject = new JSONObject();

        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
        mainObject.accumulate("TimeStamp", timeStampSeconds);
        try {
            Connection con = GetConnection.getConn();

            if (!checkUser.checkUserExists(con, userId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "User Does not Exists.");
            } /*else if (checkUser.appointmentAlreadyRequested(con, userId, apId)) {
                mainObject.accumulate("Status", "Error");
                mainObject.accumulate("Message", "Appoinment Slot Already Requested By You.");
            }*/ else {

                String sql = "UPDATE REQUESTS SET STATUS=? WHERE RECID=? AND USERID=? AND AP_ID=?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setString(1, status);
                stm.setString(2, requestId);
                stm.setString(3, studentId);
                stm.setString(4, apId);

                int value = stm.executeUpdate();

                if (value >= 1) {
                    mainObject.accumulate("Status", "Ok");
                    mainObject.accumulate("Message", "Request Status Updated.");
                } else {
                    mainObject.accumulate("Status", "Error");
                    mainObject.accumulate("Message", "Unable to Update Request Status.");
                }

                stm.close();
            }
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(GenericResource.class.getName()).log(Level.SEVERE, null, ex);
            mainObject.accumulate("Status", "Error");
            mainObject.accumulate("Message", "Error While Updating Request Status. " + ex);
        }

        return mainObject.toString();
    }

}
