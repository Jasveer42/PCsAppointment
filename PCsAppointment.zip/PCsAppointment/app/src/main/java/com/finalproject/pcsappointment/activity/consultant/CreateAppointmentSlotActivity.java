package com.finalproject.pcsappointment.activity.consultant;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.finalproject.pcsappointment.R;
import com.finalproject.pcsappointment.Utility.API;
import com.finalproject.pcsappointment.Utility.PrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class CreateAppointmentSlotActivity extends AppCompatActivity {
    private EditText etDate, etStartTime, etEndTime;
    private Button btnCreateSlot;

    static final int DATE_DIALOG_ID = 1110;
    static final int START_TIME_DIALOG_ID = 1111;
    static final int END_TIME_DIALOG_ID = 1112;
    private int CURRENT_SELECTED_DIALOG = 0;

    private int mYear, mMonth, mDay;
    private int opening_hr, closing_hr;
    private int opening_min, closing_min;

    private String TAG = CreateAppointmentSlotActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_appointment_slot);


    }

}
