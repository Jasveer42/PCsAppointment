package com.finalproject.pcsappointment.activity.consultant;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.finalproject.pcsappointment.R;
import com.finalproject.pcsappointment.Utility.PrefManager;
import com.finalproject.pcsappointment.activity.SignInActivity;
import com.finalproject.pcsappointment.activity.UserProfileActivity;

public class ConsultantMainActivity extends AppCompatActivity {
    private Button btnUserProfile, btnCreateAppointmentSlot, btnViewAppointmentSlots, btnViewRequests, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultant_main);


    }

}
